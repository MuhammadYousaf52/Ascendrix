const TAGS = { pause:'⏸ Paused', optimize:'⚡ Optimize', budget:'💰 Budget', issue:'🔴 Issue', info:'📌 Info' };

function b64(s) { try { return btoa(unescape(encodeURIComponent(s))).replace(/=/g,''); } catch(e){ return ''; } }

// Same stable key logic as content.js — path + entityId only
function stableKey(url) {
  try {
    const u = new URL(url);
    const entityId = u.searchParams.get('entityId') || u.searchParams.get('accountId') || u.searchParams.get('entityid') || '';
    return u.hostname + u.pathname + (entityId ? '?e=' + entityId : '');
  } catch(e) { return url; }
}
function storKey(url) { return 'cn2_notes_' + b64(stableKey(url)); }
function metaKey(url)  { return 'cn2_meta_'  + b64(stableKey(url)); }

function esc(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
function formatDate(ts) {
  const d=new Date(ts), p=n=>String(n).padStart(2,'0');
  const mo=['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
  return mo[d.getMonth()]+' '+d.getDate()+', '+d.getFullYear()+'  '+p(d.getHours())+':'+p(d.getMinutes());
}

chrome.tabs.query({active:true, currentWindow:true}, tabs => {
  const tab = tabs[0];
  if (!tab) return;
  const url = tab.url || '';

  const urlEl = document.getElementById('page-url');
  urlEl.textContent = url.length > 50 ? '…'+url.slice(-50) : url;
  urlEl.title = url;

  // Show what key is being used (for debugging integrity)
  const key = stableKey(url);

  chrome.storage.local.get([storKey(url), metaKey(url)], result => {
    const notes = result[storKey(url)] || [];
    const meta  = result[metaKey(url)] || {name: tab.title || url};

    const n = notes.length;
    document.getElementById('note-count').textContent = n===1 ? '1 note' : n+' notes';
    document.getElementById('campaign-name-text').textContent = meta.name || tab.title || url;

    const body = document.getElementById('notes-body');

    if (n === 0) {
      body.innerHTML = `
        <div class="empty">
          <div class="icon">🗒️</div>
          <p>No notes yet for this campaign.<br/>Click the button below to add one.</p>
        </div>`;
      return;
    }

    body.innerHTML = '';
    [...notes].sort((a,b)=>b.ts-a.ts).forEach(note => {
      const card = document.createElement('div');
      card.className = note.tag && note.tag!=='none' ? 'note-card tag-'+note.tag : 'note-card';
      const tlabel = TAGS[note.tag] || '📄 Note';
      card.innerHTML = `
        <span class="note-tag">${esc(tlabel)}</span>
        <div class="note-text">${esc(note.text)}</div>
        <div class="note-date">${formatDate(note.ts)}</div>
      `;
      body.appendChild(card);
    });
  });

  document.getElementById('open-btn').addEventListener('click', () => {
    chrome.tabs.sendMessage(tab.id, {action:'openPanel'}, () => {
      if (chrome.runtime.lastError) {
        chrome.scripting.executeScript({
          target: {tabId: tab.id},
          func: () => {
            const root = document.getElementById('cn-root');
            if (root && root.shadowRoot) {
              const panel = root.shadowRoot.querySelector('#cn-panel');
              if (panel && panel.classList.contains('cn-hidden')) {
                root.shadowRoot.querySelector('#cn-toggle').click();
              }
            }
          }
        }).catch(()=>{});
      }
    });
    window.close();
  });
});
