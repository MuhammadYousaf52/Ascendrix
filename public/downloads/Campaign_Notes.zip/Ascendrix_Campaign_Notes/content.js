// Campaign Notes v2.0 — Robust SPA-proof injection
(function () {
  'use strict';

  // ─── Utils ──────────────────────────────────────────────────────────────────
  function b64(str) {
    try { return btoa(unescape(encodeURIComponent(str))).replace(/=/g,''); }
    catch(e) { return Math.random().toString(36).slice(2); }
  }
  function stableKey() {
    try {
      var u = new URL(location.href);
      var entityId = u.searchParams.get("entityId") || u.searchParams.get("accountId") || u.searchParams.get("entityid") || "";
      return u.hostname + u.pathname + (entityId ? "?e=" + entityId : "");
    } catch(e) { return location.href; }
  }
  function storKey() { return "cn2_notes_" + b64(stableKey()); }
  function metaKey()  { return "cn2_meta_"  + b64(stableKey()); }
  function defName()  { return (document.title || location.hostname).substring(0,60); }

  function formatDate(ts) {
    const d = new Date(ts), p = n => String(n).padStart(2,'0');
    return ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'][d.getMonth()]
      + ' ' + d.getDate() + ', ' + d.getFullYear() + '  ' + p(d.getHours()) + ':' + p(d.getMinutes());
  }
  function esc(s) { return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

  function load(cb) {
    chrome.storage.local.get([storKey(), metaKey()], r =>
      cb(r[storKey()]||[], r[metaKey()]||{name:defName()})
    );
  }
  function saveN(n,cb) { chrome.storage.local.set({[storKey()]:n}, cb||function(){}); }
  function saveM(m)    { chrome.storage.local.set({[metaKey()]:m}); }

  const TAGS = [
    {id:'pause',    emoji:'⏸', label:'Paused'},
    {id:'optimize', emoji:'⚡', label:'Optimize'},
    {id:'budget',   emoji:'💰', label:'Budget'},
    {id:'issue',    emoji:'🔴', label:'Issue'},
    {id:'info',     emoji:'📌', label:'Info'},
  ];

  // ─── State ──────────────────────────────────────────────────────────────────
  let notes=[], meta={name:defName()}, open=false, selTag='none', renaming=false, lastUrl=location.href;
  let shadow = null;

  // ─── Inject ─────────────────────────────────────────────────────────────────
  function inject() {
    if (document.getElementById('cn-root')) return;

    const host = document.createElement('div');
    host.id = 'cn-root';
    host.style.cssText = 'all:unset;position:fixed;z-index:2147483647;bottom:0;right:0;width:0;height:0;';
    document.body.appendChild(host);

    shadow = host.attachShadow({mode:'open'});

    // Load CSS via link (web_accessible_resource)
    const link = document.createElement('link');
    link.rel = 'stylesheet';
    link.href = chrome.runtime.getURL('content.css');
    shadow.appendChild(link);

    // Build HTML
    const wrap = document.createElement('div');
    wrap.innerHTML = buildHTML();
    shadow.appendChild(wrap);

    // Build tag pills
    const tagRow = shadow.querySelector('#cn-tag-row');
    TAGS.forEach(t => {
      const pill = document.createElement('button');
      pill.className = 'cn-tag-pill';
      pill.dataset.tag = t.id;
      pill.textContent = t.emoji + ' ' + t.label;
      pill.onclick = () => {
        selTag = selTag===t.id ? 'none' : t.id;
        tagRow.querySelectorAll('.cn-tag-pill').forEach(p => {
          p.className = 'cn-tag-pill';
          if (p.dataset.tag===selTag) p.classList.add('cn-sel-'+selTag);
        });
      };
      tagRow.appendChild(pill);
    });

    wire();
    load((n,m) => { notes=n; meta=m; rerender(); renderMeta(); });
  }

  function buildHTML() {
    return `
    <button id="cn-toggle">
      <span class="cn-icon">📝</span>
      <span id="cn-badge" class="cn-hidden">0</span>
    </button>

    <div id="cn-panel" class="cn-hidden">
      <div id="cn-header">
        <div id="cn-header-top">
          <div id="cn-title-area">
            <div id="cn-logo-wrap"><img src="${chrome.runtime.getURL('icons/icon48.png')}" alt="Ascendrix" style="width:18px;height:18px;object-fit:contain"/></div>
            <span id="cn-title">Campaign Notes</span>
            <span id="cn-count-chip">0 notes</span>
          </div>
          <button id="cn-close">✕</button>
        </div>
        <div id="cn-campaign-row">
          <span id="cn-campaign-icon">🎯</span>
          <span id="cn-campaign-name-display"></span>
          <button id="cn-rename-btn">Rename</button>
          <input id="cn-rename-input" class="cn-hidden" type="text" placeholder="Campaign name…" maxlength="80"/>
        </div>
      </div>

      <div id="cn-notes-list">
        <div id="cn-empty">
          <span class="cn-empty-icon">🗒️</span>
          <p>No notes yet for this campaign.<br/><span>Add your first note below ↓</span></p>
        </div>
      </div>

      <div id="cn-add-area">
        <div id="cn-tag-row"></div>
        <div id="cn-input-row">
          <textarea id="cn-note-input" rows="1" placeholder="Write a note… (Enter to save, Shift+Enter for new line)"></textarea>
          <button id="cn-add-btn">＋</button>
        </div>
      </div>
    </div>`;
  }

  // ─── Wire events ────────────────────────────────────────────────────────────
  function wire() {
    const $ = s => shadow.querySelector(s);

    // Toggle panel
    $('#cn-toggle').onclick = () => { open ? closePanel() : openPanel(); };
    $('#cn-close').onclick  = () => closePanel();

    // Rename
    $('#cn-rename-btn').onclick = () => {
      renaming = true;
      $('#cn-campaign-name-display').classList.add('cn-hidden');
      $('#cn-rename-btn').classList.add('cn-hidden');
      $('#cn-rename-input').classList.remove('cn-hidden');
      $('#cn-rename-input').focus();
      $('#cn-rename-input').select();
    };

    function doRename() {
      const v = $('#cn-rename-input').value.trim();
      if (v) { meta.name=v; saveM(meta); }
      renaming=false;
      $('#cn-rename-input').classList.add('cn-hidden');
      $('#cn-campaign-name-display').classList.remove('cn-hidden');
      $('#cn-rename-btn').classList.remove('cn-hidden');
      renderMeta();
    }

    $('#cn-rename-input').onkeydown = e => {
      if (e.key==='Enter') { e.preventDefault(); doRename(); }
      if (e.key==='Escape') {
        renaming=false;
        $('#cn-rename-input').classList.add('cn-hidden');
        $('#cn-campaign-name-display').classList.remove('cn-hidden');
        $('#cn-rename-btn').classList.remove('cn-hidden');
      }
    };
    $('#cn-rename-input').onblur = () => { if(renaming) doRename(); };

    // Add note
    $('#cn-add-btn').onclick = () => addNote();
    $('#cn-note-input').onkeydown = e => {
      if (e.key==='Enter' && !e.shiftKey) { e.preventDefault(); addNote(); }
    };
    $('#cn-note-input').oninput = function() {
      this.style.height='auto';
      this.style.height = Math.min(this.scrollHeight,110)+'px';
    };
  }

  function openPanel() {
    open = true;
    const panel = shadow.querySelector('#cn-panel');
    panel.classList.remove('cn-hidden');
    panel.classList.add('cn-animate-in');
    setTimeout(() => panel.classList.remove('cn-animate-in'), 350);
    setTimeout(() => shadow.querySelector('#cn-note-input').focus(), 50);
  }

  function closePanel() {
    open = false;
    shadow.querySelector('#cn-panel').classList.add('cn-hidden');
  }

  // ─── Add note ───────────────────────────────────────────────────────────────
  function addNote() {
    const inp = shadow.querySelector('#cn-note-input');
    const text = inp.value.trim();
    if (!text) return;
    notes.unshift({
      id: Date.now().toString(36) + Math.random().toString(36).slice(2,5),
      text, tag: selTag, ts: Date.now()
    });
    saveN(notes, rerender);
    inp.value = '';
    inp.style.height = '';
    inp.focus();
  }

  // ─── Render ─────────────────────────────────────────────────────────────────
  function rerender() {
    if (!shadow) return;
    const $ = s => shadow.querySelector(s);

    // Badge
    const badge = $('#cn-badge');
    badge.textContent = notes.length > 99 ? '99+' : notes.length;
    notes.length > 0 ? badge.classList.remove('cn-hidden') : badge.classList.add('cn-hidden');

    // Chip
    $('#cn-count-chip').textContent = notes.length===1 ? '1 note' : notes.length+' notes';

    // Clear cards
    const list = $('#cn-notes-list');
    list.querySelectorAll('.cn-note-card').forEach(el => el.remove());

    if (notes.length===0) { $('#cn-empty').style.display=''; return; }
    $('#cn-empty').style.display='none';

    [...notes].sort((a,b)=>b.ts-a.ts).forEach(note => {
      const tagDef = TAGS.find(t=>t.id===note.tag);
      const card = document.createElement('div');
      card.className = 'cn-note-card' + (tagDef ? ' cn-tag-'+note.tag : '');
      card.dataset.id = note.id;

      const tclass = tagDef ? 'cn-note-tag cn-tag-lbl-'+note.tag : 'cn-note-tag cn-tag-lbl-none';
      const tlabel = tagDef ? tagDef.emoji+' '+tagDef.label : '📄 Note';

      card.innerHTML = `
        <div class="cn-note-header">
          <span class="${tclass}">${esc(tlabel)}</span>
          <div class="cn-note-actions">
            <button class="cn-note-action-btn cn-edit" title="Edit">✏️</button>
            <button class="cn-note-action-btn cn-delete" title="Delete">🗑️</button>
          </div>
        </div>
        <div class="cn-note-text">${esc(note.text)}</div>
        <textarea class="cn-note-edit-textarea" rows="3">${esc(note.text)}</textarea>
        <div class="cn-note-footer">
          <span class="cn-note-date">${formatDate(note.ts)}</span>
          <div class="cn-edit-confirm-btns">
            <button class="cn-cancel-btn">Cancel</button>
            <button class="cn-save-btn">Save</button>
          </div>
        </div>
      `;

      const textEl = card.querySelector('.cn-note-text');
      const textarea = card.querySelector('.cn-note-edit-textarea');
      const confirmBtns = card.querySelector('.cn-edit-confirm-btns');

      card.querySelector('.cn-edit').onclick = () => {
        textEl.classList.add('cn-editing');
        textarea.classList.add('cn-visible');
        confirmBtns.classList.add('cn-visible');
        textarea.focus();
      };
      card.querySelector('.cn-cancel-btn').onclick = () => {
        textEl.classList.remove('cn-editing');
        textarea.classList.remove('cn-visible');
        confirmBtns.classList.remove('cn-visible');
        textarea.value = note.text;
      };
      card.querySelector('.cn-save-btn').onclick = () => {
        const v = textarea.value.trim();
        if (!v) return;
        note.text=v; note.ts=Date.now();
        saveN(notes, rerender);
      };
      card.querySelector('.cn-delete').onclick = () => {
        card.style.opacity='0'; card.style.transform='scale(0.95)';
        card.style.transition='all 0.2s';
        setTimeout(() => { notes=notes.filter(n=>n.id!==note.id); saveN(notes,rerender); }, 180);
      };

      list.appendChild(card);
    });
  }

  function renderMeta() {
    if (!shadow) return;
    const d = shadow.querySelector('#cn-campaign-name-display');
    const i = shadow.querySelector('#cn-rename-input');
    if (d) d.textContent = meta.name;
    if (i) i.value = meta.name;
  }

  // ─── Keep alive + SPA watcher ────────────────────────────────────────────────
  function keepAlive() {
    if (!document.getElementById('cn-root')) {
      open=false; shadow=null;
      inject();
    }
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      load((n,m) => { notes=n; meta=m; rerender(); renderMeta(); });
    }
  }

  // ─── Listen for popup message ────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener(msg => {
    if (msg.action==='openPanel') {
      if (!document.getElementById('cn-root')) inject();
      setTimeout(() => { if (!open) openPanel(); }, 150);
    }
  });

  // ─── Boot ────────────────────────────────────────────────────────────────────
  if (document.body) {
    inject();
  } else {
    document.addEventListener('DOMContentLoaded', inject);
  }

  setInterval(keepAlive, 1500);

})();
