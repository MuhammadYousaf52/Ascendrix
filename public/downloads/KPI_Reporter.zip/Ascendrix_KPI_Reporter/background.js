chrome.runtime.onInstalled.addListener(() => {
  console.log('[Ascendrix KPI] v4.0 ready');
});
