'use strict';

// ─── PALETTE ─────────────────────────────────────────────────
const COLORS = ['#3B82F6','#60A5FA','#0EA5E9','#22D3EE','#818CF8','#A78BFA','#38BDF8'];

// ─── STORAGE ─────────────────────────────────────────────────
const store = {
  async get(keys)  { return chrome.storage.local.get(keys); },
  async set(obj)   { return chrome.storage.local.set(obj); }
};
async function getAccounts()       { const d = await store.get('accounts');  return d.accounts || []; }
async function saveAccounts(a)     { await store.set({ accounts: a }); }
async function getSelId()          { const d = await store.get('selId');     return d.selId || null; }
async function setSelId(id)        { await store.set({ selId: id }); }
async function getTheme()          { const d = await store.get('theme');     return d.theme || 'dark'; }
async function setTheme(t)         { await store.set({ theme: t }); }

// ─── TABS ─────────────────────────────────────────────────────
async function getActiveTab() {
  return new Promise(r => chrome.tabs.query({ active: true, currentWindow: true }, t => r(t[0] || null)));
}

function extractId(urlOrId) {
  if (!urlOrId) return null;
  const m = (urlOrId+'').match(/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  if (m) return m[1];
  if (/^[a-zA-Z0-9-_]{20,}$/.test((urlOrId+'').trim())) return (urlOrId+'').trim();
  return null;
}

// ─── FETCH CSV (runs inside Sheets page = has Google cookies) ─
async function fetchCSV(tabId, spreadsheetId, sheetName) {
  const results = await chrome.scripting.executeScript({
    target: { tabId },
    func: async (sid, tab) => {
      const base = `https://docs.google.com/spreadsheets/d/${sid}/gviz/tq?tqx=out:csv`;
      const url  = tab ? `${base}&sheet=${encodeURIComponent(tab)}&range=A:S`
                       : `${base}&range=A:S`;
      const res  = await fetch(url, { credentials: 'include' });
      if (!res.ok) throw new Error(`HTTP ${res.status}: ${res.statusText}`);
      return res.text();
    },
    args: [spreadsheetId, sheetName || '']
  });
  if (results[0].error) throw new Error(results[0].error.message);
  if (!results[0].result) throw new Error('Empty response from sheet');
  return results[0].result;
}

// ─── READ SHEET TAB NAMES FROM DOM ───────────────────────────
async function readTabNames(tabId) {
  const r = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const sel = [
        '.docs-sheet-tab-name',
        '[aria-selected] .docs-sheet-tab-name',
        '.goog-inline-block.docs-tab-name'
      ].join(',');
      return [...new Set([...document.querySelectorAll(sel)]
        .map(el => el.textContent.trim()).filter(Boolean))];
    }
  });
  return r[0]?.result || [];
}

// ─── READ ACTIVE TAB NAME FROM DOM ───────────────────────────
async function readActiveTabName(tabId) {
  const r = await chrome.scripting.executeScript({
    target: { tabId },
    func: () => {
      const a = document.querySelector(
        '.docs-sheet-active-tab .docs-sheet-tab-name,' +
        '[aria-selected="true"] .docs-sheet-tab-name'
      );
      return a ? a.textContent.trim() : '';
    }
  });
  return r[0]?.result || '';
}

// ─── CSV PARSER ───────────────────────────────────────────────
function parseCSV(text) {
  const rows = [];
  for (const line of text.split('\n')) {
    if (!line.trim()) continue;
    const cols = []; let cur = '', inQ = false;
    for (let i = 0; i < line.length; i++) {
      const c = line[i];
      if (c === '"') {
        if (inQ && line[i+1] === '"') { cur += '"'; i++; } else inQ = !inQ;
      } else if (c === ',' && !inQ) { cols.push(cur.trim()); cur = ''; }
      else cur += c;
    }
    cols.push(cur.trim()); rows.push(cols);
  }
  return rows;
}

// ─── COLUMN DETECTION ─────────────────────────────────────────
function detectCols(header) {
  const m = {};
  header.forEach((c, i) => {
    const k = (c||'').toString().trim().toLowerCase();
    if (k === 'date')                          m.date       = i;
    if (k === 'week')                          m.week       = i;
    if (k === 'total sales')                   m.totalSales = i;
    if (k === 'ppc spend' || k === 'ad spend') m.adSpend    = i;
    if (k === 'ppc sales' || k === 'ad sales') m.adSales    = i;
    if (k === 'acos')                          m.acos       = i;
    if (k === 'tacos')                         m.tacos      = i;
  });
  return m;
}

// ─── IS WEEKLY SHEET? ─────────────────────────────────────────
function isWeeklySheet(rows) {
  if (!rows || rows.length < 2) return false;
  const header = rows[0];
  // Header says "Week"
  if ((header[0]||'').toString().trim().toLowerCase() === 'week') return true;
  // First data cell is a small integer (week number 1–53)
  const v = (rows[1]?.[0]||'').toString().trim();
  const n = parseInt(v, 10);
  return !isNaN(n) && n >= 1 && n <= 53 && !/[\/\-\.]/.test(v);
}

// ─── DATE MATCHING ────────────────────────────────────────────
function dateVariants(iso) {
  const [y,m,d] = iso.split('-');
  const di = parseInt(d), mi = parseInt(m);
  return new Set([
    `${d}/${m}/${y}`, `${di}/${mi}/${y}`, `${di}/${m}/${y}`, `${d}/${mi}/${y}`,
    `${m}/${d}/${y}`, `${mi}/${di}/${y}`,
    `${y}-${m}-${d}`, `${y}/${m}/${d}`,
    `${d}-${m}-${y}`, `${d}.${m}.${y}`
  ]);
}

// ─── KPI FORMATTERS ───────────────────────────────────────────
function money(v) {
  if (v==null||v==='') return 'N/A';
  const n = parseFloat((v+'').replace(/[$,\s]/g,''));
  return isNaN(n) ? 'N/A' : '$'+Math.round(n).toLocaleString('en-US');
}
function pct(v) {
  if (v==null||v==='') return 'N/A';
  const s = (v+'').trim(); return s.endsWith('%') ? s : s+'%';
}
function fmtDate(iso) {
  const [y,m,d] = iso.split('-');
  return `${parseInt(d)}/${m}/${y}`;
}
function currentWeekNum() {
  const now = new Date(), start = new Date(now.getFullYear(),0,1);
  return Math.ceil(((now - start) / 86400000 + start.getDay()+1) / 7);
}

function buildDailyKPI(iso, name, row, col) {
  return [
    fmtDate(iso), name,
    `Total Sales =${money(row[col.totalSales])}`,
    `Ad Spend = ${money(row[col.adSpend])}`,
    `Ad Sales = ${money(row[col.adSales])},`,
    `ACOS = ${pct(row[col.acos])}`,
    `TACOS = ${pct(row[col.tacos])}`
  ].join('\n');
}

function buildWeeklyKPI(weekNum, name, row, col) {
  return [
    `Week ${weekNum}`, name,
    `Total Sales =${money(row[col.totalSales])}`,
    `Ad Spend = ${money(row[col.adSpend])}`,
    `Ad Sales = ${money(row[col.adSales])},`,
    `ACOS = ${pct(row[col.acos])}`,
    `TACOS = ${pct(row[col.tacos])}`
  ].join('\n');
}

// ─── UI HELPERS ───────────────────────────────────────────────
const esc = s => (s||'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');

function setStatus(msg, type='') {
  const el = document.getElementById('status');
  el.innerHTML = type==='load'
    ? `<span class="spinner"></span>${msg}`
    : msg;
  el.className = type;
}

function showWeeklyInputs(isWeekly) {
  document.getElementById('dateFieldWrap').style.display = isWeekly ? 'none' : '';
  document.getElementById('weekFieldWrap').style.display = isWeekly ? '' : 'none';
}

// ─── THEME ────────────────────────────────────────────────────
async function applyTheme(theme) {
  document.documentElement.setAttribute('data-theme', theme === 'light' ? 'light' : '');
  document.getElementById('themeLabel').textContent = theme === 'light' ? 'LIGHT' : 'DARK';
  await setTheme(theme);
}

// ─── RENDER: GENERATE VIEW ────────────────────────────────────
async function renderGenerateView() {
  const accounts = await getAccounts();
  const selId    = await getSelId();
  const cont     = document.getElementById('genAccountList');
  const pill     = document.getElementById('selectedPill');
  cont.innerHTML = '';

  if (!accounts.length) {
    cont.innerHTML = `<div class="empty-state">Go to <strong>Sheets</strong> tab<br/>to add your brand accounts.</div>`;
    pill.textContent = 'None';
    return;
  }

  accounts.forEach((acc, idx) => {
    const color = acc.color || COLORS[idx % COLORS.length];
    const isWeekly = acc.type === 'weekly';
    const card = document.createElement('div');
    card.className = 'account-card' + (acc.id === selId ? ' active' : '');
    card.innerHTML = `
      <div class="card-color-bar" style="background:${color}"></div>
      <div class="card-info">
        <div class="card-name">${esc(acc.name)}</div>
        <div class="card-meta">
          <span class="card-type-badge ${isWeekly ? 'type-weekly' : 'type-daily'}">
            ${isWeekly ? '📆 Weekly' : '📅 Daily'}
          </span>
          ${acc.sheetTab ? `<span style="color:var(--text-dim)">Tab: ${esc(acc.sheetTab)}</span>` : ''}
        </div>
      </div>
      <div class="card-select-dot" style="color:${acc.id === selId ? color : 'var(--text-dim)'}">
        ${acc.id === selId ? '●' : '○'}
      </div>`;

    card.addEventListener('click', async () => {
      await setSelId(acc.id);
      await renderGenerateView();
      await populateTabs(acc);
    });
    cont.appendChild(card);
  });

  const active = accounts.find(a => a.id === selId);
  pill.textContent = active ? active.name : 'None selected';

  if (active) {
    showWeeklyInputs(active.type === 'weekly');
    await populateTabs(active);
  }
}

// ─── POPULATE SHEET TAB DROPDOWN ─────────────────────────────
async function populateTabs(acc) {
  const sel = document.getElementById('sheetSelect');
  if (acc.sheetTab) {
    sel.innerHTML = `<option value="${esc(acc.sheetTab)}">${esc(acc.sheetTab)}</option>`;
    return;
  }
  sel.innerHTML = '<option value="">Auto-detect</option>';
  try {
    const allTabs = await new Promise(r =>
      chrome.tabs.query({ url:`https://docs.google.com/spreadsheets/d/${acc.spreadsheetId}/*` }, r)
    );
    if (!allTabs.length) return;
    const names = await readTabNames(allTabs[0].id);
    if (names.length) {
      sel.innerHTML = '<option value="">Auto-detect</option>';
      names.forEach(n => { const o = document.createElement('option'); o.value=n; o.textContent=n; sel.appendChild(o); });
    }
  } catch { /* silent */ }
}

// ─── GENERATE KPI ─────────────────────────────────────────────
async function generateKPI() {
  const accounts = await getAccounts();
  const selId    = await getSelId();
  const acc      = accounts.find(a => a.id === selId);
  const sheetName = document.getElementById('sheetSelect').value;
  const btn       = document.getElementById('generateBtn');

  if (!acc) { setStatus('⚠️ Select an account first', 'err'); return; }

  const isWeekly = acc.type === 'weekly';
  const iso       = document.getElementById('dateInput').value;
  const weekNum   = parseInt(document.getElementById('weekInput').value, 10);

  if (!isWeekly && !iso)             { setStatus('⚠️ Pick a date', 'err'); return; }
  if (isWeekly && (!weekNum || weekNum < 1 || weekNum > 53)) {
    setStatus('⚠️ Enter a valid week number (1–53)', 'err'); return;
  }

  btn.disabled = true;
  setStatus('Fetching data…', 'load');
  document.getElementById('outputBox').style.display = 'none';

  try {
    // Find a Chrome tab that has this sheet open
    let targetTab = (await new Promise(r =>
      chrome.tabs.query({ url:`https://docs.google.com/spreadsheets/d/${acc.spreadsheetId}/*` }, r)
    ))[0];

    if (!targetTab) {
      const active = await getActiveTab();
      if (active?.url?.includes(acc.spreadsheetId)) targetTab = active;
    }

    if (!targetTab) throw new Error(
      `Open this sheet in Chrome first:\ndocs.google.com/spreadsheets/d/${acc.spreadsheetId}/`
    );

    const tab = sheetName || acc.sheetTab || '';
    setStatus(`Reading "${tab || 'default tab'}"…`, 'load');

    const csv   = await fetchCSV(targetTab.id, acc.spreadsheetId, tab);
    const rows  = parseCSV(csv);
    if (rows.length < 2) throw new Error('Sheet is empty');

    const col   = detectCols(rows[0]);
    const data  = rows.slice(1);

    let match, kpi;

    if (isWeekly) {
      // Match by week number in column A
      const weekColIdx = col.week ?? 0;
      match = data.find(r => parseInt((r[weekColIdx]||'').toString().trim(), 10) === weekNum);
      if (!match) {
        const samples = data.slice(0,8).map(r => r[weekColIdx]).filter(Boolean).join(', ');
        throw new Error(`Week ${weekNum} not found.\nAvailable weeks: ${samples || 'unknown'}`);
      }
      kpi = buildWeeklyKPI(weekNum, acc.name, match, col);
    } else {
      // Match by date
      const variants = dateVariants(iso);
      const dateColIdx = col.date ?? 0;
      match = data.find(r => variants.has((r[dateColIdx]||'').toString().trim()));
      if (!match) {
        const samples = data.slice(0,5).map(r => r[dateColIdx]).filter(Boolean).join(', ');
        throw new Error(`No data for ${iso}.\nSheet date examples: ${samples || 'unknown'}`);
      }
      kpi = buildDailyKPI(iso, acc.name, match, col);
    }

    document.getElementById('kpiOutput').textContent = kpi;
    document.getElementById('outputBox').style.display = 'block';
    setStatus('✓ KPI ready — copy and paste to WhatsApp', 'ok');

  } catch(err) {
    setStatus('Error: ' + err.message, 'err');
    console.error('[Ascendrix]', err);
  } finally {
    btn.disabled = false;
  }
}

// ─── RENDER: ACCOUNTS VIEW ────────────────────────────────────
async function renderAccountsView() {
  const accounts = await getAccounts();
  const selId    = await getSelId();
  const list     = document.getElementById('accountsList');
  list.innerHTML = '';

  if (!accounts.length) {
    list.innerHTML = `<div class="empty-state">No sheets added yet.<br/>Click <strong>+ Add Sheet</strong> to start.</div>`;
    return;
  }

  accounts.forEach((acc, idx) => {
    const color    = acc.color || COLORS[idx % COLORS.length];
    const isWeekly = acc.type === 'weekly';
    const card = document.createElement('div');
    card.className = 'account-card' + (acc.id === selId ? ' active' : '');
    card.innerHTML = `
      <div class="card-color-bar" style="background:${color}"></div>
      <div class="card-info">
        <div class="card-name">${esc(acc.name)}</div>
        <div class="card-meta">
          <span class="card-type-badge ${isWeekly ? 'type-weekly' : 'type-daily'}">
            ${isWeekly ? '📆 Weekly' : '📅 Daily'}
          </span>
          ${acc.sheetTab ? `<span>Tab: ${esc(acc.sheetTab)}</span>` : ''}
        </div>
      </div>
      <button class="btn-del" data-id="${acc.id}">×</button>`;

    card.addEventListener('click', async e => {
      if (e.target.classList.contains('btn-del')) return;
      await setSelId(acc.id);
      await renderAccountsView();
      await renderGenerateView();
    });
    card.querySelector('.btn-del').addEventListener('click', async () => {
      const all = await getAccounts();
      await saveAccounts(all.filter(a => a.id !== acc.id));
      if (selId === acc.id) await setSelId(null);
      await renderAccountsView();
      await renderGenerateView();
    });
    list.appendChild(card);
  });
}

// ─── CAPTURE OPEN SHEET ───────────────────────────────────────
async function captureSheet() {
  const tab = await getActiveTab();
  if (!tab?.url?.includes('docs.google.com/spreadsheets')) {
    alert('Please open a Google Sheet in Chrome first, then click this button.');
    return;
  }
  const sid = extractId(tab.url);
  if (!sid) { alert('Could not read spreadsheet ID from this URL.'); return; }
  document.getElementById('newUrl').value = sid;
  try {
    const name = await readActiveTabName(tab.id);
    if (name) document.getElementById('newTab').value = name;
  } catch { /* ignore */ }
}

// ─── ADD ACCOUNT ──────────────────────────────────────────────
async function confirmAdd() {
  const name = document.getElementById('newName').value.trim();
  const url  = document.getElementById('newUrl').value.trim();
  const tab  = document.getElementById('newTab').value.trim();
  const type = document.querySelector('#typeToggle .type-opt.selected')?.dataset.val || 'daily';

  if (!name) { alert('Enter a brand/account name.'); return; }
  if (!url)  { alert('Paste a Sheet URL or use Capture button.'); return; }
  const sid = extractId(url);
  if (!sid)  { alert('Could not find a spreadsheet ID in that URL.'); return; }

  const accounts = await getAccounts();
  const newAcc = {
    id: Date.now().toString(),
    name, spreadsheetId: sid,
    sheetTab: tab, type,
    color: COLORS[accounts.length % COLORS.length]
  };
  accounts.push(newAcc);
  await saveAccounts(accounts);
  await setSelId(newAcc.id);

  ['newName','newUrl','newTab'].forEach(id => document.getElementById(id).value = '');
  document.getElementById('addForm').classList.add('hidden');
  await renderAccountsView();
  await renderGenerateView();
}

// ─── INIT ─────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  // Apply saved theme
  const savedTheme = await getTheme();
  document.documentElement.setAttribute('data-theme', savedTheme === 'light' ? 'light' : '');
  document.getElementById('themeLabel').textContent = savedTheme === 'light' ? 'LIGHT' : 'DARK';

  // Default date = today
  const now = new Date();
  document.getElementById('dateInput').value =
    `${now.getFullYear()}-${String(now.getMonth()+1).padStart(2,'0')}-${String(now.getDate()).padStart(2,'0')}`;
  // Default week = current
  document.getElementById('weekInput').value = currentWeekNum();

  // Theme toggle
  document.getElementById('themeBtn').addEventListener('click', async () => {
    const cur = document.documentElement.getAttribute('data-theme');
    const next = cur === 'light' ? 'dark' : 'light';
    document.documentElement.setAttribute('data-theme', next === 'light' ? 'light' : '');
    document.getElementById('themeLabel').textContent = next === 'light' ? 'LIGHT' : 'DARK';
    await setTheme(next);
  });

  // Nav tabs
  document.querySelectorAll('.nav-tab').forEach(btn => {
    btn.addEventListener('click', async () => {
      document.querySelectorAll('.nav-tab').forEach(b => b.classList.remove('active'));
      document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
      btn.classList.add('active');
      document.getElementById(`view-${btn.dataset.view}`).classList.add('active');
      if (btn.dataset.view === 'accounts') await renderAccountsView();
      if (btn.dataset.view === 'generate') await renderGenerateView();
    });
  });

  // Type toggle in add form
  document.querySelectorAll('#typeToggle .type-opt').forEach(opt => {
    opt.addEventListener('click', () => {
      document.querySelectorAll('#typeToggle .type-opt').forEach(o => o.classList.remove('selected'));
      opt.classList.add('selected');
    });
  });

  // Add form
  document.getElementById('showAddBtn')  .addEventListener('click', () => document.getElementById('addForm').classList.toggle('hidden'));
  document.getElementById('addCancelBtn').addEventListener('click', () => document.getElementById('addForm').classList.add('hidden'));
  document.getElementById('addConfirmBtn').addEventListener('click', confirmAdd);
  document.getElementById('captureBtn')  .addEventListener('click', captureSheet);

  // Generate / copy / clear
  document.getElementById('generateBtn').addEventListener('click', generateKPI);

  document.getElementById('copyBtn').addEventListener('click', async () => {
    const text = document.getElementById('kpiOutput').textContent;
    try { await navigator.clipboard.writeText(text); } catch {
      const ta = document.createElement('textarea'); ta.value = text;
      document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta);
    }
    const btn = document.getElementById('copyBtn');
    btn.textContent = '✅ Copied!'; btn.classList.add('copied');
    setStatus('Copied! Open WhatsApp and paste 🚀', 'ok');
    setTimeout(() => { btn.textContent = '📋 Copy to Clipboard'; btn.classList.remove('copied'); }, 2500);
  });

  document.getElementById('clearBtn').addEventListener('click', () => {
    document.getElementById('outputBox').style.display = 'none';
    setStatus('','');
  });

  await renderGenerateView();
});
